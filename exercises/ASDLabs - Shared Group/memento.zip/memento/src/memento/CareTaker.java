/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package memento;

import java.util.ArrayList;

/**
 *
 * @author 984930
 */
public class CareTaker {
    
    public ArrayList<Memento> savedState = new ArrayList<>();
    
    public void addMemento(Memento m){
    savedState.add(m);
    }
    
    public Memento getMemento(int index){
        return savedState.get(index);
    }
}
