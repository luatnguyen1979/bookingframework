/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package memento;

/**
 *
 * @author 984930
 */
public class Originator {
    
    private Person state;
    
    public void set(Person state){
       System.out.println("Originator: Setting State");
       this.state = state;
    }
    
    public Memento saveToMemento(){
        System.out.println("Originator: Save to Memento");
        return new Memento(state);
    }
    
    public void restoreFromMemento(Memento m){
        state = m.getSavedState();
        System.out.println("Originator: get Saved Memento");
    }
}
